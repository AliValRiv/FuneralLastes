<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Mail\SofiMail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facedes\Password;
use Validator;
use Illuminate\Validation\Rules\Password as PassValidate;
use App\Http\Controllers\API\BaseController as BaseController;
use Illuminate\Support\Facedes\Mail;
use Carbon\Carbon; 

class ForgotPasswordController extends BaseController
{
    public function forgot(Request $request){
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',]);

        if ($validator->fails()) {
            return $this->sendError('Error.', ['error'=>'Email not exists']);
        }

        $token = rand(1000,9999);
        
        $newreset = DB::table('password_resets')
            ->where('email', $request->email)->first();
        if(!$newreset) {
            DB::table('password_resets')->insert([
                'email' => $request->email,
                'token' => $token,
                'created_at' => Carbon::now()
            ]);
        }
        else{
            DB::table('password_resets')
            ->where('email', $request->email)->update([
                'token' => $token,
                'created_at' => Carbon::now()
            ]);
        }

        $details = [
            'title' => 'Mail from Sofi',
            'body' => 'This is your reset password code: ',
            'code' => $token,
        ];

        \Mail::to($request->email)->send(new SofiMail($details));

        $success = $request->email;
        return $this->sendResponse($success, 'Mail sent');
    }

    public function resetPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
            'password' => ['required', 
                PassValidate::min(8)
                ->mixedCase()
                ->numbers()
                ->symbols()],
            'token' => 'required' ]);
        if ($validator->fails()) {
            return $this->sendError('Error validation.', $validator->errors());
        }

        $token = DB::table('password_resets')
        ->where('token', $request->token)->first();
        if (!$token) return $this->sendError('Error.', ['error'=>'Wrong code.']);

        $user = User::where('email', $token->email)->first();
        if (!$user) return $this->sendError('Error.', ['error'=>'Email not exists']);

        $user->password = \Hash::make($request->password);
        $user->update();

        DB::table('password_resets')->where('email', $user->email)
        ->delete();

        $success = $user->email;
        return $this->sendResponse($success, 'Password has been changed');
    }
}
